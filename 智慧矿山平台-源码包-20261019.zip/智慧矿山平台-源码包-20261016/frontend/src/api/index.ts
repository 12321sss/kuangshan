import http from './http'
import type {
  AdminUser, Alarm, CrsOption, DisplacementSeries, Extraction, Imagery, InterpretTask,
  OverviewStats, PermCatalog, PitForecast, PitYearly, Project, Role, SceneItem,
  ScreenSummary, Sensor, SensorDataPoint, Station, TimeSeriesFrame, TimeSeriesGroup,
  VegetationYearly, WarningRule
} from './types'

/** 业务 API 集中定义（认证相关走 stores/auth.ts 直连）
 *  数据中台：列表类接口都带 projectId，按当前选中项目过滤 */

export const projectApi = {
  list: (): Promise<Project[]> => http.get('/projects'),
  get: (id: number): Promise<Project> => http.get(`/projects/${id}`),
  create: (p: Partial<Project>): Promise<Project> => http.post('/projects', p),
  update: (id: number, p: Partial<Project>): Promise<Project> => http.put(`/projects/${id}`, p),
  remove: (id: number): Promise<void> => http.delete(`/projects/${id}`),
  setMembers: (id: number, members: string[]): Promise<Project> =>
    http.put(`/projects/${id}/members`, members)
}

export const sensorApi = {
  list: (projectId?: number): Promise<Sensor[]> =>
    http.get('/sensors', { params: { projectId } }),
  data: (id: string, hours = 24): Promise<SensorDataPoint[]> =>
    http.get(`/sensors/${id}/data`, { params: { hours } }),
  displacement: (id: string, hours = 24): Promise<DisplacementSeries> =>
    http.get(`/sensors/${id}/displacement`, { params: { hours } })
}

export const taskApi = {
  list: (projectId?: number): Promise<InterpretTask[]> =>
    http.get('/tasks', { params: { projectId } }),
  get: (id: number): Promise<InterpretTask> => http.get(`/tasks/${id}`),
  create: (req: { name: string; projectId: number; algoType: string; imageName?: string }): Promise<InterpretTask> =>
    http.post('/tasks', req),
  remove: (id: number): Promise<void> => http.delete(`/tasks/${id}`)
}

export const overviewApi = {
  stats: (projectId?: number): Promise<OverviewStats> =>
    http.get('/overview/stats', { params: { projectId } })
}

export const alarmApi = {
  list: (projectId?: number): Promise<Alarm[]> => http.get('/alarms', { params: { projectId } }),
  ack: (id: number): Promise<Alarm> => http.post(`/alarms/${id}/ack`)
}

export const warningApi = {
  list: (): Promise<WarningRule[]> => http.get('/warning-rules'),
  update: (rule: WarningRule): Promise<WarningRule> => http.put(`/warning-rules/${rule.id}`, rule)
}

export const stationApi = {
  list: (projectId?: number): Promise<Station[]> => http.get('/stations', { params: { projectId } }),
  create: (s: Partial<Station>): Promise<Station> => http.post('/stations', s),
  update: (id: string, s: Partial<Station>): Promise<Station> => http.put(`/stations/${id}`, s),
  remove: (id: string): Promise<void> => http.delete(`/stations/${id}`)
}

export const analysisApi = {
  /** 地物面积时序（真实解译结果按日期聚合） */
  areaTimeseries: (params?: { projectId?: number; classType?: string }): Promise<AreaTimeseriesRow[]> =>
    http.get('/analysis/area-timeseries', { params }),
  /** 采坑趋势外推（含免责声明与不确定性带宽，非实测） */
  pitForecast: (projectId?: number): Promise<PitForecastResult> =>
    http.get('/analysis/pit-forecast', { params: { projectId } }),
  /** 变化概览（各类地物面积与记录数） */
  changeSummary: (projectId?: number): Promise<ChangeSummary> =>
    http.get('/analysis/change-summary', { params: { projectId } }),
  /** @deprecated 旧硬编码接口已随 AnalysisController 重写移除 */
  pitYearlyOld: (projectId?: number): Promise<PitYearly[]> =>
    http.get('/analysis/pit-yearly', { params: { projectId } }),
}

export const screenApi = {
  summary: (projectId: number): Promise<ScreenSummary> =>
    http.get('/screen/summary', { params: { projectId } })
}

export const userApi = {
  list: (): Promise<AdminUser[]> => http.get('/users'),
  options: (): Promise<{ username: string; displayName: string }[]> => http.get('/users/options'),
  create: (u: { username: string; displayName: string; password: string; phone?: string; role: string }): Promise<AdminUser> =>
    http.post('/users', u),
  update: (username: string, u: { displayName: string; phone?: string; role: string; status: string; newPassword?: string }): Promise<AdminUser> =>
    http.put(`/users/${username}`, u),
  remove: (username: string): Promise<void> => http.delete(`/users/${username}`)
}

export const roleApi = {
  list: (): Promise<Role[]> => http.get('/roles'),
  catalog: (): Promise<PermCatalog> => http.get('/roles/catalog'),
  create: (r: Partial<Role>): Promise<Role> => http.post('/roles', r),
  update: (code: string, r: Partial<Role>): Promise<Role> => http.put(`/roles/${code}`, r),
  remove: (code: string): Promise<void> => http.delete(`/roles/${code}`)
}

export const extractionApi = {
  list: (projectId?: number): Promise<Extraction[]> => http.get('/extractions', { params: { projectId } }),
  get: (id: number): Promise<Extraction> => http.get(`/extractions/${id}`),
  /** 提交真实解译任务（选影像 + 圈 AOI + 选类别），返回 inference taskId */
  submit: (req: {
    projectId: number
    imageryId: number
    name?: string
    classType: string
    aoi: number[][]
    /** 上传影像需指定数据源（GF2/GF7）决定波段映射 */
    satellite?: string
  }): Promise<{ taskId: string; status: string }> => http.post('/extractions/submit', req),
  /** 提交在线 Sentinel-2 解译（无需本地影像，AWS STAC 在线拉景） */
  submitOnline: (req: {
    projectId: number
    name?: string
    classType: string
    aoi: number[][]
    startDate: string
    endDate: string
    maxCloud?: number
    threshold?: number
    minAreaPx?: number
  }): Promise<{ taskId: string; status: string }> => http.post('/extractions/submit-online', req),
  /** 直接保存前端已算好的解译结果（遥感提取页用） */
  save: (req: {
    projectId: number
    name?: string
    classType: string
    features: number[][][]
    aoiJson: string
    coveragePct: number
    aoiAreaHa: number
    acquisitionDate?: string
    satellite?: string
  }): Promise<Extraction> => http.post('/extractions/save', req),
  remove: (id: number): Promise<void> => http.delete(`/extractions/${id}`)
}

export const imageryApi = {
  list: (params?: { projectId?: number; source?: string }): Promise<Imagery[]> =>
    http.get('/imagery', { params }),
  get: (id: number): Promise<Imagery> => http.get(`/imagery/${id}`),
  /** 可选坐标系列表（上传时选择） */
  crsOptions: (): Promise<CrsOption[]> => http.get('/imagery/crs-options'),
  /** 检索 Sentinel-2 公开场景
   *  实测后端转发 Copernicus 需 20-30 秒（跨境 + 云量属性过滤），
   *  必须单独给更长超时，否则会被全局 15s 掐断并误报「网络异常」 */
  searchScenes: (params: {
    lng: number
    lat: number
    start: string
    end: string
    maxCloud: number
  }): Promise<SceneItem[]> =>
    http.get('/imagery/scenes/search', { params, timeout: 90000 }),
  /** 上传高分影像（multipart），坐标系由用户选择 */
  upload: (req: {
    file: File
    projectId?: number
    name?: string
    crs: string
    acquisitionDate: string
    resolutionM?: number
    bounds: number[]
  }): Promise<Imagery> => {
    const fd = new FormData()
    fd.append('file', req.file)
    if (req.projectId !== undefined) fd.append('projectId', String(req.projectId))
    if (req.name) fd.append('name', req.name)
    fd.append('crs', req.crs)
    fd.append('acquisitionDate', req.acquisitionDate)
    if (req.resolutionM !== undefined) fd.append('resolutionM', String(req.resolutionM))
    // bounds 重复参数：Spring 的 List<Double> 接多值
    req.bounds.forEach((b) => fd.append('bounds', String(b)))
    // 去掉默认的 JSON Content-Type，让浏览器自己带 multipart boundary
    return http.post('/imagery/upload', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 120000
    })
  },
  /** 登记一景公开数据到影像库 */
  registerPublic: (req: {
    projectId: number
    name: string
    source: string
    productId: string
    acquisitionDate: string
    cloudCover?: number
    resolutionM?: number
    bounds: number[]
    note?: string
  }): Promise<Imagery> => http.post('/imagery/register-public', req),
  remove: (id: number): Promise<void> => http.delete(`/imagery/${id}`)
}

export const timeSeriesApi = {
  /** 按 AOI 指纹分组的时序列表（期数多的排前面） */
  groups: (projectId?: number): Promise<TimeSeriesGroup[]> =>
    http.get('/timeseries/groups', { params: { projectId } }),
  /** 某个 AOI 的完整时序序列（按日期升序，含几何） */
  sequence: (signature: string): Promise<TimeSeriesFrame[]> =>
    http.get(`/timeseries/${signature}`)
}
