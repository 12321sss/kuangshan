<template>
  <div v-loading="loading">
    <!-- 指标卡片 -->
    <div class="stat-grid">
      <div v-for="card in cards" :key="card.label" class="stat-card">
        <div class="stat-label">{{ card.label }}</div>
        <div class="stat-value" :style="{ color: card.color }">
          {{ card.value }}<span class="stat-unit">{{ card.unit }}</span>
        </div>
        <div class="stat-foot">{{ card.foot }}</div>
      </div>
    </div>

    <div class="panel-row">
      <!-- 传感器曲线 -->
      <el-card class="panel chart-panel" shadow="never">
        <template #header>
          <div class="panel-head">
            <span>排土场北坡位移（DISP-03 · 告警设备）</span>
            <el-radio-group v-model="hours" size="small" @change="loadChart">
              <el-radio-button :value="24">24h</el-radio-button>
              <el-radio-button :value="72">72h</el-radio-button>
              <el-radio-button :value="168">7天</el-radio-button>
            </el-radio-group>
          </div>
        </template>
        <div ref="chartRef" class="chart"></div>
      </el-card>

      <!-- 告警与任务 -->
      <el-card class="panel side-panel" shadow="never">
        <template #header><span>当前告警</span></template>
        <div v-if="alarms.length === 0" class="empty">暂无告警</div>
        <div v-for="s in alarms" :key="s.id" class="alarm-item">
          <el-tag type="danger" size="small">告警</el-tag>
          <div class="alarm-info">
            <div class="alarm-name">{{ s.name }}</div>
            <div class="alarm-detail">{{ s.latestValue }} {{ s.unit }} · 超阈值</div>
          </div>
        </div>
        <el-divider />
        <div class="sub-title">最新任务</div>
        <div v-for="t in recentTasks" :key="t.id" class="task-item">
          <span class="task-name">{{ t.name }}</span>
          <el-tag :type="taskTagType(t.status)" size="small">{{ taskStatusLabel(t.status) }}</el-tag>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import * as echarts from 'echarts'
import { ElMessage } from 'element-plus'
import { overviewApi, sensorApi, taskApi } from '@/api'
import { useProjectStore } from '@/stores/project'
import type { InterpretTask, OverviewStats, Sensor } from '@/api/types'

const projectStore = useProjectStore()

const loading = ref(true)
const stats = ref<OverviewStats | null>(null)
const sensors = ref<Sensor[]>([])
const tasks = ref<InterpretTask[]>([])
const hours = ref(24)

const chartRef = ref<HTMLDivElement>()
// 图表实例：用普通 let + 类型标注，避免 SFC 编译期对 ref<命名空间.类型>() 泛型写法的解析问题
let chart: echarts.ECharts | undefined

const cards = computed(() => [
  { label: '影像库', value: stats.value?.imageCount ?? '-', unit: ' 景', color: '#2f54eb', foot: '已入库影像' },
  { label: '运行中任务', value: stats.value?.taskRunning ?? '-', unit: ' 个', color: '#0ea5e9', foot: '解译任务' },
  { label: '在线传感器', value: stats.value?.sensorOnline ?? '-', unit: ' 台', color: '#22c55e', foot: 'IoT 设备在线' },
  { label: '当前告警', value: stats.value?.sensorAlarm ?? '-', unit: ' 条', color: '#ef4444', foot: '位移计阈值告警' }
])

const alarms = computed(() => sensors.value.filter((s) => s.status === 'ALARM'))
const recentTasks = computed(() => tasks.value.slice(0, 4))

function taskTagType(status: InterpretTask['status']) {
  return { SUCCESS: 'success', RUNNING: 'primary', PENDING: 'info', FAILED: 'danger' }[status] as any
}
function taskStatusLabel(status: InterpretTask['status']) {
  return { SUCCESS: '完成', RUNNING: '运行中', PENDING: '排队中', FAILED: '失败' }[status]
}

async function loadChart() {
  try {
    // 取当前项目第一台位移计；没有位移计就取第一台设备
    const target = sensors.value.find((s) => s.type === 'DISP') || sensors.value[0]
    if (!target) return
    const data = await sensorApi.data(target.id, hours.value)
    if (!chart && chartRef.value) {
      chart = echarts.init(chartRef.value)
    }
    chart?.setOption({
      grid: { left: 44, right: 16, top: 30, bottom: 28 },
      tooltip: { trigger: 'axis' },
      xAxis: {
        type: 'category',
        data: data.map((p) => p.time.slice(5, 13).replace('T', ' ')),
        axisLabel: { fontSize: 11, color: '#86909c' }
      },
      yAxis: {
        type: 'value', name: 'mm',
        axisLabel: { fontSize: 11, color: '#86909c' },
        splitLine: { lineStyle: { color: '#f0f0f0' } }
      },
      series: [{
        type: 'line',
        data: data.map((p) => p.value),
        smooth: true,
        symbol: 'none',
        lineStyle: { color: '#ef4444', width: 2 },
        areaStyle: { color: 'rgba(239,68,68,0.08)' },
        markLine: {
          silent: true,
          symbol: 'none',
          lineStyle: { color: '#f59e0b', type: 'dashed' },
          data: [{ yAxis: 6, label: { formatter: '告警阈值 6mm', fontSize: 11 } }]
        }
      }]
    }, true)
  } catch (e: any) {
    ElMessage.error(e.message)
  }
}

onMounted(async () => {
  try {
    const [s, sensorList, taskList] = await Promise.all([
      overviewApi.stats(projectStore.currentId),
      sensorApi.list(projectStore.currentId),
      taskApi.list(projectStore.currentId)
    ])
    stats.value = s
    sensors.value = sensorList
    tasks.value = taskList
    await loadChart()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    loading.value = false
  }
  window.addEventListener('resize', resize)
})

// 切换工程 -> 全量刷新
watch(() => projectStore.currentId, async () => {
  loading.value = true
  try {
    const [s, sensorList, taskList] = await Promise.all([
      overviewApi.stats(projectStore.currentId),
      sensorApi.list(projectStore.currentId),
      taskApi.list(projectStore.currentId)
    ])
    stats.value = s
    sensors.value = sensorList
    tasks.value = taskList
    await loadChart()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    loading.value = false
  }
})

function resize() { chart?.resize() }

onBeforeUnmount(() => {
  window.removeEventListener('resize', resize)
  chart?.dispose()
})
</script>

<style scoped>
.stat-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 16px;
}

.stat-card {
  background: #fff;
  border: 1px solid #eceef2;
  border-radius: 10px;
  padding: 18px 20px;
}

.stat-label { font-size: 13px; color: #86909c; }
.stat-value { font-size: 30px; font-weight: 700; margin: 8px 0 4px; font-variant-numeric: tabular-nums; }
.stat-unit { font-size: 13px; font-weight: 400; color: #86909c; }
.stat-foot { font-size: 12px; color: #a9aeb8; }

.panel-row {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 16px;
}

.panel { border: 1px solid #eceef2; border-radius: 10px; }
.panel-head { display: flex; align-items: center; justify-content: space-between; }
.chart { height: 320px; }

.empty { color: #a9aeb8; font-size: 13px; padding: 8px 0; }

.alarm-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; }
.alarm-name { font-size: 13px; font-weight: 600; }
.alarm-detail { font-size: 12px; color: #ef4444; }

.sub-title { font-size: 13px; font-weight: 600; margin-bottom: 8px; }
.task-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 6px 0; font-size: 13px;
}
.task-name {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  max-width: 220px; color: #4e5969;
}
</style>
