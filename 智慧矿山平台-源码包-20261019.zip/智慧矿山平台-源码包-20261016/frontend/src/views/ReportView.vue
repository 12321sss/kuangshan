<template>
  <div v-loading="loading">
    <el-alert type="info" :closable="false" class="notice">
      <template #title>
        报告基于<b>真实解译结果</b>与传感器数据自动生成，数据可追溯到每次提取记录。
        输出口径为「潜在水土流失风险筛查」，非实测侵蚀量。
      </template>
    </el-alert>

    <el-card shadow="never" class="panel">
      <template #header><span>报告预览（生成前数据概览）</span></template>

      <div class="stats-row">
        <div class="stat-card">
          <div class="stat-num">{{ summary.totalRecords }}</div>
          <div class="stat-label">解译记录数</div>
        </div>
        <div class="stat-card">
          <div class="stat-num">{{ series.length }}</div>
          <div class="stat-label">时序期数</div>
        </div>
        <div class="stat-card">
          <div class="stat-num">{{ sensorOnline }}</div>
          <div class="stat-label">在线设备</div>
        </div>
        <div class="stat-card">
          <div class="stat-num" :class="{ warn: sensorAlarm > 0 }">{{ sensorAlarm }}</div>
          <div class="stat-label">未处理告警</div>
        </div>
      </div>

      <div v-if="!summary.totalRecords" class="empty-tip">
        当前项目还没有解译记录，报告内容会为空。请先到「遥感解译」模块完成至少一次提取。
      </div>

      <div v-else class="preview">
        <div class="preview-item">
          <span class="label">地物构成</span>
          <el-tag
            v-for="c in summary.classes"
            :key="c.classType"
            size="small"
            class="cls-tag"
          >
            {{ classLabel(c.classType) }} {{ haToKm2(c.totalAreaHa) }} km²
          </el-tag>
        </div>
        <div class="preview-item">
          <span class="label">时序变化</span>
          <span>{{ series.length }} 期（{{ series[0]?.date }} → {{ series[series.length - 1]?.date }}）</span>
        </div>
      </div>
    </el-card>

    <el-card shadow="never" class="panel">
      <template #header><span>生成报告</span></template>
      <div class="gen-row">
        <el-button
          type="primary"
          :loading="generating"
          :disabled="!summary.totalRecords"
          @click="doGenerate"
        >
          生成 Word 报告
        </el-button>
        <span class="gen-hint">
          {{ summary.totalRecords ? '将生成 .docx 文件，可直接下载' : '请先完成至少一次解译提取' }}
        </span>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { analysisApi, overviewApi } from '@/api'
import { reportApi } from '@/api/sentinel'
import { useProjectStore } from '@/stores/project'
import { haToKm2 } from '@/utils/format'
import type { AreaTimeseriesRow, ChangeSummary, PitForecastResult } from '@/api/types'

const projectStore = useProjectStore()
const loading = ref(false)
const generating = ref(false)

const series = ref<AreaTimeseriesRow[]>([])
const summary = ref<ChangeSummary>({ totalRecords: 0, classes: [], note: '' })
const forecast = ref<PitForecastResult | null>(null)
const sensorOnline = ref(0)
const sensorAlarm = ref(0)

const CLASS_LABEL: Record<string, string> = {
  PIT: '采坑', BARE: '裸地扰动', VEGETATION: '植被',
  WATER: '水体', DUMP: '排土场', TAILINGS: '尾矿库', ROAD: '道路设施',
  BUILDING: '建筑', MOUNTAIN: '山体'
}
function classLabel(c: string) {
  return CLASS_LABEL[c] || c
}

async function loadData() {
  loading.value = true
  const pid = projectStore.currentId ?? undefined
  try {
    const [s, sum, ov] = await Promise.all([
      analysisApi.areaTimeseries({ projectId: pid }),
      analysisApi.changeSummary(pid),
      overviewApi.stats(pid)
    ])
    series.value = s
    summary.value = sum
    sensorOnline.value = ov.sensorOnline ?? 0
    sensorAlarm.value = ov.sensorAlarm ?? 0
    try {
      forecast.value = await analysisApi.pitForecast(pid)
    } catch {
      forecast.value = null
    }
  } catch (e: any) {
    ElMessage.error('数据加载失败：' + (e.message || ''))
  } finally {
    loading.value = false
  }
}

async function doGenerate() {
  generating.value = true
  try {
    const res = await reportApi.generate({
      projectName: projectStore.current?.name || '默认项目',
      timeseries: series.value,
      summary: summary.value.classes,
      forecast: forecast.value || {},
      sensorOnline: sensorOnline.value,
      sensorAlarm: sensorAlarm.value
    })
    // base64 转 blob 下载
    const byteChars = atob(res.docx_base64)
    const bytes = new Uint8Array(byteChars.length)
    for (let i = 0; i < byteChars.length; i++) bytes[i] = byteChars.charCodeAt(i)
    const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = res.filename
    a.click()
    URL.revokeObjectURL(url)
    ElMessage.success('报告已生成并开始下载')
  } catch (e: any) {
    ElMessage.error('报告生成失败：' + (e.message || ''))
  } finally {
    generating.value = false
  }
}

onMounted(() => loadData())
</script>

<style scoped>
.notice {
  margin-bottom: 12px;
}
.panel {
  margin-bottom: 12px;
}
.stats-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 16px;
}
.stat-card {
  background: var(--el-fill-color-light);
  border-radius: 10px;
  padding: 16px;
  text-align: center;
}
.stat-num {
  font-size: 28px;
  font-weight: 600;
  color: var(--el-color-primary);
}
.stat-num.warn {
  color: var(--el-color-danger);
}
.stat-label {
  font-size: 12px;
  color: var(--el-text-color-secondary);
  margin-top: 4px;
}
.empty-tip {
  color: var(--el-color-warning);
  font-size: 13px;
  padding: 8px 0;
}
.preview-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 0;
  font-size: 13px;
}
.preview-item .label {
  color: var(--el-text-color-secondary);
  width: 80px;
  flex-shrink: 0;
}
.cls-tag {
  margin-right: 4px;
}
.gen-row {
  display: flex;
  align-items: center;
  gap: 12px;
}
.gen-hint {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
</style>