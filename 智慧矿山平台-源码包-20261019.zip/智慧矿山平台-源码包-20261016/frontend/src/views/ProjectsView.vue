<template>
  <el-card shadow="never" class="page-card" v-loading="loading">
    <template #header>
      <div class="head">
        <span>矿区项目</span>
        <div class="head-actions">
          <el-input v-model="keyword" placeholder="搜索项目名称" size="small" clearable style="width: 200px" :prefix-icon="Search" />
          <el-button v-if="auth.hasAction('action:project-manage')" type="primary" :icon="Plus" @click="onCreate">新增项目</el-button>
        </div>
      </div>
    </template>
    <el-table :data="filtered" stripe>
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="name" label="项目名称" min-width="200" />
      <el-table-column prop="region" label="区域" width="140" />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusTag(row.status)" size="small">{{ statusLabel(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="成员" width="150">
        <template #default="{ row }">
          <el-tag v-for="m in row.members.slice(0, 3)" :key="m" size="small" effect="plain" style="margin-right:4px">{{ m }}</el-tag>
          <span v-if="row.members.length > 3" class="more">+{{ row.members.length - 3 }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="manager" label="负责人" width="100" />
      <el-table-column prop="description" label="说明" min-width="200" show-overflow-tooltip />
      <el-table-column v-if="auth.hasAction('action:project-manage')" label="操作" width="210" fixed="right">
        <template #default="{ row }">
          <el-button size="small" text type="primary" @click="onEdit(row)">编辑</el-button>
          <el-button size="small" text type="primary" @click="onMembers(row)">成员</el-button>
          <el-popconfirm title="确定删除该项目？" @confirm="onDelete(row)">
            <template #reference>
              <el-button size="small" text type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新增/编辑对话框 -->
    <el-dialog v-model="dialogVisible" :title="editing?.id ? '编辑项目' : '新增项目'" width="480px">
      <el-form v-if="editing" label-width="90px">
        <el-form-item label="项目名称" required>
          <el-input v-model="editing.name" />
        </el-form-item>
        <el-form-item label="区域">
          <el-input v-model="editing.region" placeholder="如：江西省赣州市宁都县" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="editing.status" style="width: 100%">
            <el-option value="RUNNING" label="进行中" />
            <el-option value="PLANNING" label="规划中" />
            <el-option value="ARCHIVED" label="已归档" />
          </el-select>
        </el-form-item>
        <el-form-item label="负责人">
          <el-input v-model="editing.manager" />
        </el-form-item>
        <el-form-item label="说明">
          <el-input v-model="editing.description" type="textarea" :rows="3" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="onSave">保存</el-button>
      </template>
    </el-dialog>

    <!-- 成员分配对话框 -->
    <el-dialog v-model="memberVisible" :title="`成员分配 · ${memberProject?.name || ''}`" width="420px">
      <el-checkbox-group v-model="memberSelection">
        <div v-for="u in userOptions" :key="u.username" class="member-row">
          <el-checkbox :value="u.username">{{ u.displayName }}（{{ u.username }}）</el-checkbox>
        </div>
      </el-checkbox-group>
      <div class="member-hint">管理员可见全部项目，无需分配</div>
      <template #footer>
        <el-button @click="memberVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="onSaveMembers">保存</el-button>
      </template>
    </el-dialog>
  </el-card>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Plus, Search } from '@element-plus/icons-vue'
import { projectApi, userApi } from '@/api'
import { useAuthStore } from '@/stores/auth'
import { useProjectStore } from '@/stores/project'
import type { Project } from '@/api/types'

const auth = useAuthStore()
const projectStore = useProjectStore()

const loading = ref(true)
const saving = ref(false)
const keyword = ref('')
const dialogVisible = ref(false)
const memberVisible = ref(false)
const editing = ref<Partial<Project> | null>(null)
const memberProject = ref<Project | null>(null)
const memberSelection = ref<string[]>([])
const userOptions = ref<{ username: string; displayName: string }[]>([])

const filtered = computed(() =>
  keyword.value
    ? projectStore.projects.filter((p) => p.name.includes(keyword.value))
    : projectStore.projects
)

function statusTag(s: Project['status']) {
  return { RUNNING: 'success', PLANNING: 'warning', ARCHIVED: 'info' }[s] as any
}
function statusLabel(s: Project['status']) {
  return { RUNNING: '进行中', PLANNING: '规划中', ARCHIVED: '已归档' }[s]
}

async function load() {
  loading.value = true
  try {
    await projectStore.load()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    loading.value = false
  }
}

function onCreate() {
  editing.value = { name: '', region: '', status: 'PLANNING', manager: auth.user?.displayName || '', description: '' }
  dialogVisible.value = true
}

function onEdit(row: Project) {
  editing.value = { ...row }
  dialogVisible.value = true
}

async function onSave() {
  if (!editing.value?.name) {
    ElMessage.warning('项目名称不能为空')
    return
  }
  saving.value = true
  try {
    if (editing.value.id) {
      await projectApi.update(editing.value.id, editing.value)
    } else {
      await projectApi.create(editing.value)
    }
    ElMessage.success('已保存')
    dialogVisible.value = false
    await load()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    saving.value = false
  }
}

async function onDelete(row: Project) {
  try {
    await projectApi.remove(row.id)
    ElMessage.success('已删除')
    await load()
  } catch (e: any) {
    ElMessage.error(e.message)
  }
}

async function onMembers(row: Project) {
  memberProject.value = row
  memberSelection.value = [...row.members]
  if (userOptions.value.length === 0) {
    userOptions.value = await userApi.options()
  }
  memberVisible.value = true
}

async function onSaveMembers() {
  if (!memberProject.value) return
  saving.value = true
  try {
    await projectApi.setMembers(memberProject.value.id, memberSelection.value)
    ElMessage.success('成员已更新')
    memberVisible.value = false
    await load()
  } catch (e: any) {
    ElMessage.error(e.message)
  } finally {
    saving.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.page-card { border: 1px solid #eceef2; border-radius: 10px; }
.head { display: flex; align-items: center; justify-content: space-between; }
.head-actions { display: flex; gap: 10px; align-items: center; }
.more { font-size: 12px; color: #a9aeb8; }
.member-row { padding: 4px 0; }
.member-hint { margin-top: 12px; font-size: 12px; color: #a9aeb8; }
</style>
