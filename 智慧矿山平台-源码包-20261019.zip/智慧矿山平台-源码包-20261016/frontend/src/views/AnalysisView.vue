<template>
  <div v-loading="loading">
    <el-alert :type="hasData ? 'info' : 'warning'" :closable="false" class="notice">
      <template #title>
        <template v-if="hasData">
          面积数据来自<b>真实解译结果</b>按影像拍摄日期累计，可追溯到每次提取记录。
          预测为<b>趋势外推（带不确定性区间）</b>，不是实测值；
          「持续复绿」不等于「生态修复成功」。
        </template>
        <template v-else>
          当前项目还没有真实提取记录，本页暂无数据。
          请先到<b>在线提取</b>页对影像执行解译。
        </template>
      </template>
    </el-alert>

    <!-- 类别筛选 -->
    <div class="filter-row">
      <el-radio-group v-model="classFilter" size="small" @change="reload">
        <el-radio-button value="">全部地物</el-radio-button>
        <el-radio-button value="PIT">采坑</el-radio-button>
        <el-radio-button value="BARE">裸地扰动</el-radio-button>
        <el-radio-button value="VEGETATION">植被</el-radio-button>
        <el-radio-button value="WATER">水体</el-radio-button>
      </el-radio-group>
    </div>

    <div class="panel-row">
      <!-- 面积时序 -->
      <el-card shadow="never" class="panel">
        <template #header>
          <span>地物面积时序变化</span>
          <span class="unit-note">单位：平方千米（km²）</span>
        </template>
        <div ref="areaChartRef" class="chart"></div>
      </el-card>

      <!-- 分类占比 -->
      <el-card shadow="never" class="panel">
        <template #header>
          <span>各类地物累计面积</span>
          <span class="unit-note">基于全部真实提取记录</span>
        </template>
        <div ref="pieChartRef" class="chart"></div>
      </el-card>
    </div>

    <!-- 采坑预测（口径敏感，单独成卡并显式标注） -->
    <el-card v-if="forecast && !forecast.insufficient" shadow="never" class="panel">
      <template #header>
        <span>采坑扩张趋势外推</span>
        <span class="unit-note">单位：平方千米（km²）</span>
      </template>
      <el-alert type="warning" :closable="false" class="forecast-note">
        <template #title>
          <b>{{ forecast.method }}</b> ——{{ forecast.disclaimer }}
        </template>
      </el-alert>
      <el-table :data="forecast.forecast" stripe size="small">
        <el-table-column prop="date" label="外推日期" width="120" />
        <el-table-column label="面积中值(km²)" width="120">
          <template #default="{ row }">{{ haToKm2(row.areaHa) }}</template>
        </el-table-column>
        <el-table-column label="下限(km²)" width="110">
          <template #default="{ row }">{{ haToKm2(row.lowerHa) }}</template>
        </el-table-column>
        <el-table-column label="上限(km²)" width="110">
          <template #default="{ row }">{{ haToKm2(row.upperHa) }}</template>
        </el-table-column>
        <el-table-column label="不确定度(±km²)" width="130">
          <template #default="{ row }">
            <span class="uncertain">{{ haToKm2(row.uncertaintyHa) }}</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 明细表 -->
    <el-card shadow="never" class="panel">
      <template #header><span>时序明细（真实解译记录聚合）</span></template>
      <el-table :data="series" stripe size="small" empty-text="暂无提取记录">
        <el-table-column prop="date" label="影像日期" width="130" />
        <el-table-column label="合计面积(km²)" width="130"><template #default="{ row }">{{ haToKm2(row.totalAreaHa) }}</template></el-table-column>
        <el-table-column label="较上期变化(km²)" width="140">
          <template #default="{ row }">
            <span :style="{ color: row.changeHa > 0 ? '#ef4444' : row.changeHa < 0 ? '#22c55e' : '' }">
              {{ row.changeHa > 0 ? '+' : '' }}{{ haToKm2(row.changeHa) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column label="分类构成" min-width="240">
          <template #default="{ row }">
            <el-tag
              v-for="(area, cls) in row.byClass"
              :key="cls"
              size="small"
              class="cls-tag"
              :style="{ background: classColor(cls), color: '#fff', border: 'none' }"
            >
              {{ classLabel(cls) }} {{ haToKm2(area) }}
            </el-tag>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import * as echarts from 'echarts'
import { analysisApi } from '@/api'
import { haToKm2, haToKm2Num } from '@/utils/format'
import { useProjectStore } from '@/stores/project'
import type { AreaTimeseriesRow, ChangeSummary, PitForecastResult } from '@/api/types'

const projectStore = useProjectStore()
const loading = ref(false)
const classFilter = ref('')

const series = ref<AreaTimeseriesRow[]>([])
const summary = ref<ChangeSummary | null>(null)
const forecast = ref<PitForecastResult | null>(null)

const areaChartRef = ref<HTMLDivElement>()
const pieChartRef = ref<HTMLDivElement>()
let areaChart: echarts.ECharts | undefined
let pieChart: echarts.ECharts | undefined

const hasData = computed(() => series.value.length > 0)

const CLASS_LABEL: Record<string, string> = {
  PIT: '采坑', BARE: '裸地扰动', VEGETATION: '植被',
  WATER: '水体', DUMP: '排土场', TAILINGS: '尾矿库', ROAD: '道路设施'
}
const CLASS_COLOR: Record<string, string> = {
  PIT: '#ef4444', BARE: '#a8a29e', VEGETATION: '#22c55e',
  WATER: '#3b82f6', DUMP: '#f59e0b', TAILINGS: '#8b5cf6', ROAD: '#64748b'
}
function classLabel(c: string) {
  return CLASS_LABEL[c] || c
}
function classColor(c: string) {
  return CLASS_COLOR[c] || '#888'
}

async function reload() {
  loading.value = true
  const pid = projectStore.currentId ?? undefined
  try {
    const [s, sum] = await Promise.all([
      analysisApi.areaTimeseries({
        projectId: pid,
        classType: classFilter.value || undefined
      }),
      analysisApi.changeSummary(pid)
    ])
    series.value = s
    summary.value = sum
    // 预测只在未筛选类别时给出（采坑预测是专门口径）
    if (!classFilter.value) {
      try {
        forecast.value = await analysisApi.pitForecast(pid)
      } catch {
        forecast.value = null
      }
    } else {
      forecast.value = null
    }
    renderArea()
    renderPie()
  } catch (e: any) {
    series.value = []
    summary.value = null
    forecast.value = null
  } finally {
    loading.value = false
  }
}

function renderArea() {
  if (!areaChartRef.value) return
  if (!areaChart) areaChart = echarts.init(areaChartRef.value)
  const dates = series.value.map((r) => r.date)
  // 多类别堆叠
  const classes = new Set<string>()
  series.value.forEach((r) => Object.keys(r.byClass).forEach((c) => classes.add(c)))
  const seriesArr = [...classes].map((c) => ({
    name: classLabel(c),
    type: 'bar',
    stack: 'total',
    itemStyle: { color: classColor(c) },
    data: series.value.map((r) => haToKm2Num(r.byClass[c]))
  }))
  areaChart.setOption({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: [...classes].map(classLabel) },
    grid: { left: 50, right: 20, top: 40, bottom: 35 },
    xAxis: { type: 'category', data: dates },
    yAxis: { type: 'value', name: 'km²' },
    series: seriesArr.length ? seriesArr : [{ type: 'bar', data: [] }]
  }, true)
}

function renderPie() {
  if (!pieChartRef.value) return
  if (!pieChart) pieChart = echarts.init(pieChartRef.value)
  const classes = summary.value?.classes ?? []
  pieChart.setOption({
    tooltip: { trigger: 'item', formatter: '{b}: {c} km² ({d}%)' },
    legend: { orient: 'vertical', right: 10, top: 'center' },
    series: [{
      type: 'pie',
      radius: ['40%', '65%'],
      label: { formatter: '{b}\n{c} km²' },
      data: classes.map((c) => ({
        name: classLabel(c.classType),
        value: haToKm2Num(c.totalAreaHa),
        itemStyle: { color: classColor(c.classType) }
      }))
    }]
  }, true)
}

watch(() => projectStore.currentId, () => reload())

onMounted(() => {
  reload()
  window.addEventListener('resize', handleResize)
})

function handleResize() {
  areaChart?.resize()
  pieChart?.resize()
}

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  areaChart?.dispose()
  pieChart?.dispose()
})
</script>

<style scoped>
.notice {
  margin-bottom: 12px;
}
.filter-row {
  margin-bottom: 12px;
}
.panel-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-bottom: 12px;
}
.chart {
  height: 300px;
}
.unit-note {
  float: right;
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.forecast-note {
  margin-bottom: 10px;
}
.uncertain {
  color: var(--el-color-warning);
}
.cls-tag {
  margin-right: 4px;
}
@media (max-width: 1100px) {
  .panel-row {
    grid-template-columns: 1fr;
  }
}
</style>