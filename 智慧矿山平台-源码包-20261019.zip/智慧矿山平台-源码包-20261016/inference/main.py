"""
赣锋锂电遥感解译平台 - 解译服务（真实指数法实现）

当前阶段：CPU 可跑的真实解译链路，不依赖 GPU/torch。
- Sentinel-2 公开场景检索：sentinel_source.search()
- 上传影像解译：classify.classify()（NDVI/NDWI/NDBI 阈值分割 + 矢量化）
- GPU 服务器就绪后，classify.py 整体替换为 Mask2Former 推理，接口协议不变

接口
----
GET  /health                              存活探针
GET  /api/v1/class-types                  七类地物中文名
GET  /api/v1/scenes                       检索 Sentinel-2 场景（在线提取数据源）
POST /api/v1/inference/submit             提交解译任务（后台线程执行，算完回调 Java）
GET  /api/v1/inference/{task_id}/status   查询任务进度

回调
----
POST {callbackUrl}
     {taskId, status, classType, label, polygons, pixelCount,
      extractAreaHa, aoiAreaHa, stats, error}
"""
from __future__ import annotations

import os
import random
import threading
import time
import traceback
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

import requests
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

import sentinel_source
from classify import CLASS_LABELS, classify, ring_area_ha

# 回调共享密钥：与 Java 侧 INFERENCE_CALLBACK_TOKEN 保持一致。
# 不带此头后端会返回 401（回调端点曾可被任意伪造写入假数据）
CALLBACK_TOKEN = os.environ.get(
    "INFERENCE_CALLBACK_TOKEN", "rs-demo-inference-token-2026")

# ---- 任务存储 ----
# demo 期用内存 + 后台线程；生产切 Celery + Redis，接口协议不变。
_tasks: dict[str, dict[str, Any]] = {}
_lock = threading.Lock()


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    with _lock:
        _tasks.clear()


app = FastAPI(
    title="RS Platform Inference Service",
    version="0.2.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# 场景检索（在线提取的数据源）
# ---------------------------------------------------------------------------
@app.get("/health")
def health():
    return {"status": "UP", "service": "rs-platform-inference",
            "version": "0.2.0", "time": time.time()}


@app.get("/api/v1/class-types")
def class_types():
    """七类地物的中文名（前端与报告共用口径）"""
    return {"code": 0, "message": "success", "data": dict(CLASS_LABELS)}


@app.get("/api/v1/scenes")
def scenes(
    lng: float = Query(..., description="AOI 中心经度"),
    lat: float = Query(..., description="AOI 中心纬度"),
    start: str = Query(..., description="起始日期 YYYY-MM-DD"),
    end: str = Query(..., description="结束日期 YYYY-MM-DD"),
    maxCloud: float = Query(15.0, description="云量上限(%)"),
    limit: int = Query(20, description="最多返回场景数"),
    level: str = Query("MSIL1C", description="处理级别 MSIL1C / MSIL2A"),
):
    """检索 Sentinel-2 场景：在线提取的数据来源"""
    try:
        found = sentinel_source.search(
            lng, lat, start, end,
            max_cloud=maxCloud, limit=limit, level=level,
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502,
                            detail=f"Sentinel-2 检索失败: {e}") from e
    return {
        "code": 0,
        "message": "success",
        "data": [
            {
                "productId": s.product_id,
                "name": s.name,
                "date": s.acquisition_date.isoformat(),
                "cloudCover": round(s.cloud_cover, 2),
                "tileId": s.tile_id,
                "platform": s.platform,
                "level": s.processing_level,
                "bounds": list(s.bounds),
                "center": list(s.center),
                "sizeMb": s.size_mb,
                "hasQuicklook": bool(s.quicklook_url),
            }
            for s in found
        ],
    }


# ---------------------------------------------------------------------------
# 解译任务
# ---------------------------------------------------------------------------
class SubmitRequest(BaseModel):
    imagePath: str = Field(..., description="影像在磁盘上的路径")
    satellite: str = Field(..., description="SENTINEL2 / LANDSAT9 / GF2")
    classType: str = Field(..., description="七类地物之一")
    algoType: str = Field("INDEX", description="当前仅 INDEX（指数法）")
    aoi: list[list[float]] | None = Field(None, description="AOI 环 [[lng,lat],...]")
    thresholds: dict[str, float] | None = None
    callbackUrl: str = Field(..., description="任务完成后回调的 Java 接口")
    # 上下文透传：计算完成后原样带回Java，否则回调落库时 projectId/imageryId 为 0
    projectId: int | None = None
    imageryId: int | None = None
    name: str | None = None
    # 拍摄日期（YYYY-MM-DD）：Java 下发后需原样带回，否则落库为 NULL，
    # 时序播放按日期排序会全部退化
    acquisitionDate: str | None = None


class SubmitResponse(BaseModel):
    taskId: str
    status: str


def _aoi_bounds(aoi: list[list[float]] | None) -> tuple[float, float, float, float] | None:
    """从 AOI 环算外接矩形 (west, south, east, north)"""
    if not aoi or len(aoi) < 3:
        return None
    xs = [p[0] for p in aoi]
    ys = [p[1] for p in aoi]
    return (min(xs), min(ys), max(xs), max(ys))


def _aoi_area_ha(aoi: list[list[float]] | None) -> float:
    if not aoi:
        return 0.0
    return round(ring_area_ha(aoi), 4)


def _set(task_id: str, status: str, progress: int, **extra) -> None:
    with _lock:
        t = _tasks.get(task_id)
        if t is not None:
            t["status"] = status
            t["progress"] = progress
            t.update(extra)


def _run_task(task_id: str, req: dict[str, Any]) -> None:
    """后台线程执行真实解译并回调 Java"""
    try:
        _set(task_id, "RUNNING", 10)

        result = classify(
            path=req["imagePath"],
            satellite=req["satellite"],
            class_type=req["classType"],
            aoi_bounds=req["aoiBounds"],
            thresholds=req.get("thresholds"),
        )

        payload = {
            "taskId": task_id,
            "status": "SUCCESS" if result.polygons else "EMPTY",
            "classType": result.class_type,
            "label": result.label,
            "polygons": result.polygons,
            "pixelCount": result.pixel_count,
            "extractAreaHa": result.extract_area_ha,
            "aoiAreaHa": req["aoiAreaHa"],
            "stats": result.stats,
            # 上下文回传，Java 侧据此落库到正确项目
            "projectId": req.get("projectId"),
            "imageryId": req.get("imageryId"),
            "name": req.get("name"),
            "satellite": req.get("satellite"),
            "acquisitionDate": req.get("acquisitionDate"),
            # AOI 回传：Java 侧据此计算指纹，识别同一区域的不同期结果
            "aoi": req.get("aoi"),
            "error": None,
        }

        # 回调 Java（失败不影响本地结果留存，便于排查）
        try:
            cb = requests.post(req["callbackUrl"], json=payload, timeout=30,
                               headers={"X-Inference-Token": CALLBACK_TOKEN})
            cb.raise_for_status()
        except Exception as e:  # noqa: BLE001
            payload["callbackError"] = str(e)

        _set(task_id, payload["status"], 100, result=payload)

    except Exception as e:  # noqa: BLE001
        detail = f"{type(e).__name__}: {e}"
        traceback.print_exc()
        _set(task_id, "FAILED", 100, error=detail)
        try:
            requests.post(req["callbackUrl"], json={
                "taskId": task_id, "status": "FAILED", "error": detail,
            }, timeout=30, headers={"X-Inference-Token": CALLBACK_TOKEN})
        except Exception:
            pass


@app.post("/api/v1/inference/submit", response_model=SubmitResponse)
def submit(req: SubmitRequest):
    """提交解译任务：立即返回 taskId，实际计算在后台线程执行"""
    if req.classType not in CLASS_LABELS:
        raise HTTPException(status_code=400,
                            detail=f"不支持的地物类别: {req.classType}")
    if req.satellite.upper() not in ("SENTINEL2", "LANDSAT9", "GF2", "GF7", "UPLOAD"):
        raise HTTPException(status_code=400,
                            detail=f"不支持的数据源: {req.satellite}")

    task_id = f"inf-{int(time.time() * 1000)}-{random.randint(1000, 9999)}"
    payload = {
        "imagePath": req.imagePath,
        "satellite": req.satellite,
        "classType": req.classType,
        "aoiBounds": _aoi_bounds(req.aoi),
        "aoiAreaHa": _aoi_area_ha(req.aoi),
        "thresholds": req.thresholds,
        "callbackUrl": req.callbackUrl,
        "aoi": req.aoi,
        "projectId": req.projectId,
        "imageryId": req.imageryId,
        "name": req.name,
        "acquisitionDate": req.acquisitionDate,
    }
    with _lock:
        _tasks[task_id] = {"status": "PENDING", "progress": 0,
                           "submittedAt": time.time(), **payload}

    threading.Thread(target=_run_task, args=(task_id, payload), daemon=True).start()
    return SubmitResponse(taskId=task_id, status="PENDING")


@app.get("/api/v1/inference/{task_id}/status")
def status(task_id: str):
    with _lock:
        t = _tasks.get(task_id)
        if t is None:
            return {"code": 404, "message": f"任务不存在: {task_id}", "data": None}
        snapshot = dict(t)
    return {
        "code": 0,
        "message": "success",
        "data": {
            "taskId": task_id,
            "status": snapshot.get("status"),
            "progress": snapshot.get("progress"),
            "extractAreaHa": snapshot.get("extractAreaHa"),
            "error": snapshot.get("error"),
        },
    }


# ---------------------------------------------------------------------------
# 在线 Sentinel-2 直接解译（AWS Earth Search STAC 直连，无需本地影像文件）
# ---------------------------------------------------------------------------
# 这是「遥感提取」页的数据源：AOI + 日期 + 类型 → 在线拉景 → 剪切 → 指数 → 矢量
# 与上传影像解译（/api/v1/inference/submit，读本地文件）是两条并行的数据来源。
import sentinel as aws_sentinel  # noqa: E402

# 在线提取的类型集合：VEGETATION/WATER/BUILDING/BARE/MOUNTAIN
_ONLINE_CLASSES = {"VEGETATION", "WATER", "BUILDING", "BARE", "MOUNTAIN"}


class OnlineExtractRequest(BaseModel):
    model_config = {"populate_by_name": True}  # 允许用字段名或别名填充

    aoi: list[list[float]] = Field(..., description="AOI 环 [[lng,lat],...]")
    startDate: str = Field(..., alias="start_date", description="YYYY-MM-DD")
    endDate: str = Field(..., alias="end_date", description="YYYY-MM-DD")
    classType: str = Field(..., alias="class_type", description="VEGETATION/WATER/BUILDING/BARE/MOUNTAIN")
    maxCloud: float = Field(30.0, alias="max_cloud")
    threshold: float | None = None
    minAreaPx: int = Field(20, alias="min_area_px")


class AsyncExtractRequest(BaseModel):
    """异步解译（Java submit-online 用）：算完回调 Java，需 callbackUrl"""
    model_config = {"populate_by_name": True}

    aoi: list[list[float]] = Field(..., description="AOI 环 [[lng,lat],...]")
    startDate: str = Field(..., alias="start_date", description="YYYY-MM-DD")
    endDate: str = Field(..., alias="end_date", description="YYYY-MM-DD")
    classType: str = Field(..., alias="class_type", description="VEGETATION/WATER/BUILDING/BARE/MOUNTAIN")
    maxCloud: float = Field(30.0, alias="max_cloud")
    threshold: float | None = None
    minAreaPx: int = Field(20, alias="min_area_px")
    callbackUrl: str = Field(..., alias="callback_url", description="算完回调 Java 的接口")
    projectId: int | None = Field(None, alias="project_id")
    name: str | None = None


class OnlineSearchRequest(BaseModel):
    model_config = {"populate_by_name": True}

    aoi: list[list[float]] = Field(..., description="[[lng,lat],...] 至少 3 点")
    startDate: str = Field(..., alias="start_date", description="YYYY-MM-DD")
    endDate: str = Field(..., alias="end_date", description="YYYY-MM-DD")
    maxCloud: float = Field(30.0, alias="max_cloud")


def _geojson_to_polygons(features: list[dict]) -> list[list[list[float]]]:
    """把 sentinel.py 的 GeoJSON Feature 列表转成 Java 回调期望的
    List[List[List[Double]]] 格式（只取外环坐标）。

    Java complete() 落库的 featuresJson 用这个格式，前端 renderResult 也能解。
    """
    rings: list[list[list[float]]] = []
    for f in features:
        g = f.get("geometry") or {}
        gtype = g.get("type")
        coords = g.get("coordinates")
        if not coords:
            continue
        if gtype == "Polygon":
            rings.append(coords[0])          # 外环
        elif gtype == "MultiPolygon":
            for poly in coords:
                rings.append(poly[0])         # 每个子多边形外环
    return rings


def _run_online_task(task_id: str, req: dict) -> None:
    """后台线程：AWS STAC 在线拉景 → 剪切 → 指数 → 矢量 → 回调 Java"""
    try:
        _set(task_id, "RUNNING", 10)

        feat = aws_sentinel.search_scene(
            req["aoi"], req["startDate"], req["endDate"], req["maxCloud"])
        if feat is None:
            payload = {
                "taskId": task_id, "status": "EMPTY", "classType": req["classType"],
                "label": aws_sentinel.CLASS_INDEX.get(req["classType"], ""),
                "polygons": [], "pixelCount": 0, "extractAreaHa": 0.0,
                "aoiAreaHa": req["aoiAreaHa"],
                "stats": {}, "projectId": req.get("projectId"),
                "name": req.get("name"), "satellite": "SENTINEL2",
                "acquisitionDate": None, "aoi": req["aoi"],
                "error": None, "note": "该 AOI/日期范围内无可用的无云影像",
            }
            _set(task_id, "EMPTY", 100, result=payload)
            _post_callback(req["callbackUrl"], payload)
            return

        _set(task_id, "RUNNING", 40)

        # 按类型决定需要的波段
        need = ["B02", "B03", "B04", "B08"]
        if req["classType"] in ("WATER", "BUILDING", "BARE"):
            need.append("B11")
        clipped = aws_sentinel.clip_aoi(feat, req["aoi"], need)

        _set(task_id, "RUNNING", 70)

        if req.get("threshold") is not None:
            aws_sentinel.CLASS_THRESHOLD[req["classType"]] = req["threshold"]
        result = aws_sentinel.extract_class(
            clipped["bands"], req["classType"],
            clipped["meta"].get("B04", {}).get("transform"),
            clipped["meta"].get("B04", {}).get("crs"),
            min_area_px=req.get("minAreaPx", 20),
        )

        polygons = _geojson_to_polygons(result.get("features", []))
        # 面积：覆盖率为 AOI 内目标像元占比，AOI 面积已知 → 推算提取面积
        aoi_ha = req["aoiAreaHa"]
        extract_ha = round(aoi_ha * result["coverage_pct"] / 100.0, 4)
        # 拍摄日期：来自检索到的景（feat.properties.datetime），不是 result（result 无此字段）
        scene_datetime = (feat.get("properties", {}).get("datetime") or "")[:10] or None

        payload = {
            "taskId": task_id,
            "status": "SUCCESS" if polygons else "EMPTY",
            "classType": req["classType"],
            "label": aws_sentinel.CLASS_INDEX.get(req["classType"], ""),
            "polygons": polygons,
            "pixelCount": 0,   # 在线方案不统计像元数，用覆盖率折算
            "extractAreaHa": extract_ha,
            "aoiAreaHa": aoi_ha,
            "coveragePct": result["coverage_pct"],   # 顶层字段：Java 回调据此落库
            "stats": {"coverage_pct": result["coverage_pct"],
                      "threshold": result["threshold"],
                      "feature_count": result["feature_count"]},
            "projectId": req.get("projectId"),
            "name": req.get("name"),
            "satellite": "SENTINEL2",
            "acquisitionDate": scene_datetime,
            "aoi": req["aoi"],
            "error": None,
        }
        _set(task_id, payload["status"], 100, result=payload)
        _post_callback(req["callbackUrl"], payload)

    except Exception as e:  # noqa: BLE001
        detail = f"{type(e).__name__}: {e}"
        traceback.print_exc()
        _set(task_id, "FAILED", 100, error=detail)
        _post_callback(req["callbackUrl"], {
            "taskId": task_id, "status": "FAILED", "error": detail,
        })


def _post_callback(callback_url: str, payload: dict) -> None:
    try:
        cb = requests.post(callback_url, json=payload, timeout=30,
                            headers={"X-Inference-Token": CALLBACK_TOKEN})
        cb.raise_for_status()
    except Exception as e:  # noqa: BLE001
        print(f"[callback] 回调失败 {type(e).__name__}: {e}")


@app.post("/api/v1/sentinel/extract")
def online_extract(req: OnlineExtractRequest):
    """同步在线解译：AWS STAC 拉景 + 剪切 + 指数 + 矢量，直接返回结果。

    这是「遥感提取」页前端直连的路径 —— 同步返回 features + 覆盖率，
    前端立即上图渲染，不需要 callbackUrl（落库由前端调 Java /extractions/save）。
    """
    if req.classType not in _ONLINE_CLASSES:
        raise HTTPException(status_code=400,
                            detail=f"不支持的地物类别: {req.classType}")

    feat = aws_sentinel.search_scene(req.aoi, req.startDate, req.endDate, req.maxCloud)
    if feat is None:
        return {"code": 404, "message": "该 AOI/日期范围内无可用的无云影像", "data": None}

    # 按类型决定需要的波段
    need = ["B02", "B03", "B04", "B08"]
    if req.classType in ("WATER", "BUILDING", "BARE"):
        need.append("B11")
    clipped = aws_sentinel.clip_aoi(feat, req.aoi, need)

    if req.threshold is not None:
        aws_sentinel.CLASS_THRESHOLD[req.classType] = req.threshold
    result = aws_sentinel.extract_class(
        clipped["bands"], req.classType,
        clipped["meta"].get("B04", {}).get("transform"),
        clipped["meta"].get("B04", {}).get("crs"),
        min_area_px=req.minAreaPx,
    )

    result["scene_id"] = feat.get("id")
    result["datetime"] = feat.get("properties", {}).get("datetime")
    result["cloud_cover"] = feat.get("properties", {}).get("eo:cloud_cover")
    return {"code": 0, "message": "success", "data": result}


@app.post("/api/v1/sentinel/extract-async", response_model=SubmitResponse)
def online_extract_async(req: AsyncExtractRequest):
    """异步在线解译（Java submit-online 专用）：算完回调 Java 落库"""
    if req.classType not in _ONLINE_CLASSES:
        raise HTTPException(status_code=400,
                            detail=f"不支持的地物类别: {req.classType}")

    task_id = f"inf-{int(time.time() * 1000)}-{random.randint(1000, 9999)}"
    payload = {
        "aoi": req.aoi,
        "startDate": req.startDate,
        "endDate": req.endDate,
        "classType": req.classType,
        "maxCloud": req.maxCloud,
        "threshold": req.threshold,
        "minAreaPx": req.minAreaPx,
        "aoiAreaHa": _aoi_area_ha(req.aoi),
        "callbackUrl": req.callbackUrl,
        "projectId": req.projectId,
        "name": req.name,
    }
    with _lock:
        _tasks[task_id] = {"status": "PENDING", "progress": 0,
                           "submittedAt": time.time(), **payload}

    threading.Thread(target=_run_online_task, args=(task_id, payload), daemon=True).start()
    return SubmitResponse(taskId=task_id, status="PENDING")


@app.post("/api/v1/sentinel/search")
def online_search(req: OnlineSearchRequest):
    """在线检索最优景（不下载数据），供前端「查询影像」按钮使用"""
    try:
        feat = aws_sentinel.search_scene(req.aoi, req.startDate, req.endDate, req.maxCloud)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"检索失败: {e}") from e
    if feat is None:
        return {"code": 404, "message": "该 AOI/日期范围内无可用的无云影像", "data": None}
    props = feat.get("properties", {})
    return {
        "code": 0, "message": "success",
        "data": {
            "scene_id": feat.get("id"),
            "datetime": props.get("datetime"),
            "cloud_cover": props.get("eo:cloud_cover"),
        },
    }


@app.post("/api/v1/sentinel/preview")
def online_preview(req: OnlineSearchRequest):
    """AOI 真彩预览：检索 + 剪切 + RGB PNG（base64）"""
    try:
        feat = aws_sentinel.search_scene(req.aoi, req.startDate, req.endDate, req.maxCloud)
        if feat is None:
            return {"code": 404, "message": "无可用影像", "data": None}
        clipped = aws_sentinel.clip_aoi(feat, req.aoi, ["B02", "B03", "B04"])
        png = aws_sentinel.true_color_png(clipped["bands"])
        import base64
        return {
            "code": 0, "message": "success",
            "data": {
                "scene_id": feat.get("id"),
                "datetime": feat.get("properties", {}).get("datetime"),
                "cloud_cover": feat.get("properties", {}).get("eo:cloud_cover"),
                "image_base64": base64.b64encode(png).decode(),
            },
        }
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"剪切失败: {e}") from e


# ---------------------------------------------------------------------------
# 报告生成（S4）：基于数据库真实统计生成 Word 报告
# ---------------------------------------------------------------------------
import report as report_gen  # noqa: E402


class ReportRequest(BaseModel):
    """报告生成请求：Java 汇总好真实数据后传入"""
    projectName: str = "默认项目"
    generatedAt: str | None = None
    timeseries: list[dict] = []
    summary: list[dict] = []
    forecast: dict = {}
    sensorOnline: int = 0
    sensorAlarm: int = 0


@app.post("/api/v1/report/generate")
def generate_report(req: ReportRequest):
    """生成矿山稳定性/安全性报告，返回 docx 字节流（base64）"""
    data = req.model_dump()
    if not data.get("generatedAt"):
        data["generatedAt"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    try:
        docx_bytes = report_gen.generate_report(data)
        import base64
        return {
            "code": 0, "message": "success",
            "data": {
                "filename": f"矿山监测报告-{data['projectName']}.docx",
                "docx_base64": base64.b64encode(docx_bytes).decode(),
            },
        }
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"报告生成失败: {e}") from e
