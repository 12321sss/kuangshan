package com.ganfeng.rs.alarm;

import com.ganfeng.rs.common.BizException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 告警服务（MySQL 持久化）
 * 真实链路：IoT 阈值引擎命中规则 -> 写入告警 -> WebSocket 推送
 */
@Service
public class AlarmService {

    private final AlarmRepository repo;

    public AlarmService(AlarmRepository repo) {
        this.repo = repo;
    }

    public List<Alarm> list(Long projectId) {
        return projectId == null ? repo.findAll() : repo.findByProjectIdOrderByCreatedAtDesc(projectId);
    }

    /** 确认告警：只有未确认状态可以确认 */
    @Transactional
    public Alarm ack(long id) {
        Alarm a = repo.findById(id).orElseThrow(() -> BizException.notFound("告警不存在: " + id));
        if (!"UNACK".equals(a.getStatus())) {
            throw BizException.badRequest("该告警已处理，无需重复确认");
        }
        a.setStatus("ACKED");
        return repo.save(a);
    }
}
