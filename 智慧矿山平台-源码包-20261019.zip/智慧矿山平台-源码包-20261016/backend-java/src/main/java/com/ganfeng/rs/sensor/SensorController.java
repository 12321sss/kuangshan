package com.ganfeng.rs.sensor;

import com.ganfeng.rs.common.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 传感器控制器：按项目过滤（数据中台项目隔离）
 */
@RestController
@RequestMapping("/api/sensors")
public class SensorController {

    private final SensorService sensorService;

    public SensorController(SensorService sensorService) {
        this.sensorService = sensorService;
    }

    @GetMapping
    public ApiResponse<List<Sensor>> list(@RequestParam(required = false) Long projectId) {
        return ApiResponse.ok(sensorService.list(projectId));
    }

    @GetMapping("/{id}/data")
    public ApiResponse<List<SensorDataPoint>> data(@PathVariable String id,
                                                   @RequestParam(defaultValue = "24") int hours) {
        return ApiResponse.ok(sensorService.history(id, hours));
    }

    /** GNSS 位移多分量（X/Y/Z/合位移） */
    @GetMapping("/{id}/displacement")
    public ApiResponse<Map<String, List<SensorDataPoint>>> displacement(@PathVariable String id,
                                                                        @RequestParam(defaultValue = "24") int hours) {
        return ApiResponse.ok(sensorService.displacement(id, hours));
    }
}
