package com.ganfeng.rs.extraction;

import com.ganfeng.rs.common.ApiResponse;
import com.ganfeng.rs.common.PermissionGuard;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 在线提取控制器
 *
 * 提取已改为**真实链路**：选影像（imageryId）+ 圈 AOI + 选地物类型
 * → 提交 inference 异步计算 → 回调落库（见 InferenceCallbackController）。
 * 前端用返回的 taskId 轮询 /api/extractions。
 */
@RestController
@RequestMapping("/api/extractions")
public class ExtractionController {

    private final ExtractionService service;
    private final PermissionGuard guard;

    public ExtractionController(ExtractionService service, PermissionGuard guard) {
        this.service = service;
        this.guard = guard;
    }

    private boolean isAdmin(Authentication auth) {
        return guard.roleCodesOf(auth).contains("ADMIN");
    }

    /** 提交解译请求：imageryId 必填（影像来自影像库，不再凭空造数据）
     *  satellite 可选：上传影像需指定数据源（GF2/GF7）以决定波段映射 */
    public record SubmitRequest(
            @NotNull(message = "项目不能为空") Long projectId,
            @NotNull(message = "请选择影像") Long imageryId,
            String name,
            @NotBlank(message = "提取类型不能为空") String classType,
            @NotNull(message = "AOI 不能为空") List<List<Double>> aoi,
            String satellite
    ) {}

    @GetMapping
    public ApiResponse<List<Extraction>> list(@RequestParam(required = false) Long projectId,
                                              Authentication auth) {
        return ApiResponse.ok(service.list(projectId, auth.getName(), isAdmin(auth)));
    }

    @GetMapping("/{id}")
    public ApiResponse<Extraction> get(@PathVariable long id, Authentication auth) {
        return ApiResponse.ok(service.get(id, auth.getName(), isAdmin(auth)));
    }

    /** 提交真实解译任务，返回 inference 的 taskId 供轮询 */
    @PostMapping("/submit")
    public ApiResponse<Map<String, Object>> submit(@Valid @RequestBody SubmitRequest req,
                                                    Authentication auth) {
        guard.require(auth, "action:extract-manage");
        // 只能在自己可见的项目下发起解译
        guard.requireAccess(req.projectId(), auth.getName(), isAdmin(auth));
        String taskId = service.submit(req.projectId(), req.imageryId(), req.name(),
                req.classType(), req.aoi(), auth.getName(), req.satellite());
        return ApiResponse.ok(Map.of("taskId", taskId, "status", "PENDING"));
    }

    /** 在线 Sentinel-2 直接解译请求（遥感提取页，无需本地影像） */
    public record OnlineSubmitRequest(
            @NotNull(message = "项目不能为空") Long projectId,
            String name,
            @NotBlank(message = "提取类型不能为空") String classType,
            @NotNull(message = "AOI 不能为空") List<List<Double>> aoi,
            @NotBlank(message = "开始日期不能为空") String startDate,
            @NotBlank(message = "结束日期不能为空") String endDate,
            double maxCloud,
            Double threshold,
            int minAreaPx
    ) {}

    /** 提交在线解译：AWS Sentinel-2 在线拉景 + 指数 + 矢量，异步回调落库 */
    @PostMapping("/submit-online")
    public ApiResponse<Map<String, Object>> submitOnline(
            @Valid @RequestBody OnlineSubmitRequest req, Authentication auth) {
        guard.require(auth, "action:extract-manage");
        guard.requireAccess(req.projectId(), auth.getName(), isAdmin(auth));
        String taskId = service.submitOnline(req.projectId(), req.name(), req.classType(),
                req.aoi(), req.startDate(), req.endDate(), req.maxCloud(),
                req.threshold(), req.minAreaPx(), auth.getName());
        return ApiResponse.ok(Map.of("taskId", taskId, "status", "PENDING"));
    }

    /** 保存前端已算好的解译结果（遥感提取页直接落库，不再重算） */
    public record SaveRequest(
            @NotNull(message = "项目不能为空") Long projectId,
            String name,
            @NotBlank(message = "提取类型不能为空") String classType,
            List<List<List<Double>>> features,
            @NotBlank(message = "AOI 不能为空") String aoiJson,
            double coveragePct,
            double aoiAreaHa,
            String acquisitionDate,
            String satellite
    ) {}

    /** 直接保存解译结果（进 extractions 表，供时序/分析/权限使用） */
    @PostMapping("/save")
    public ApiResponse<Extraction> save(@Valid @RequestBody SaveRequest req,
                                         Authentication auth) {
        guard.require(auth, "action:extract-manage");
        guard.requireAccess(req.projectId(), auth.getName(), isAdmin(auth));
        Extraction e = service.save(req.projectId(), req.name(), req.classType(),
                req.features(), req.aoiJson(), req.coveragePct(), req.aoiAreaHa(),
                req.acquisitionDate(), req.satellite(), auth.getName());
        return ApiResponse.ok(e);
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable long id, Authentication auth) {
        guard.require(auth, "action:extract-manage");
        service.get(id, auth.getName(), isAdmin(auth));
        service.delete(id);
        return ApiResponse.ok(null);
    }
}