package com.ganfeng.rs.analysis;

import com.ganfeng.rs.common.ApiResponse;
import com.ganfeng.rs.common.PermissionGuard;
import com.ganfeng.rs.extraction.Extraction;
import com.ganfeng.rs.extraction.ExtractionService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 遥感监测分析（**基于真实解译结果聚合**，不再硬编码）
 *
 * 变更说明：原实现用写死的数组出图（采坑面积 {12.4, 15.8, 21.6...}）——
 * 那是演示数据不是分析结果。现在改为从 extractions 表按影像拍摄日期聚合，
 * 数据可追溯到每一次真实解译，报告里的数字才有依据。
 *
 * 口径红线：采坑面积 = 该时期所有 PIT 类提取面积之和；
 * 「预测」是趋势外推**非实测**，接口响应里带method/disclaimer，前端与报告须原样展示。
 */
@RestController
@RequestMapping("/api/analysis")
public class AnalysisController {

    private final ExtractionService extractionService;
    private final PermissionGuard guard;

    public AnalysisController(ExtractionService extractionService, PermissionGuard guard) {
        this.extractionService = extractionService;
        this.guard = guard;
    }

    /**
     * 地物面积时序（按影像拍摄日期分组）
     *
     * @param classType 可选：只统计某一类；为空则统计全部
     */
    @GetMapping("/area-timeseries")
    public ApiResponse<List<Map<String, Object>>> areaTimeseries(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String classType,
            Authentication auth) {
        List<Extraction> all = extractionService.list(projectId, auth.getName(),
                guard.roleCodesOf(auth).contains("ADMIN"));

        // key = 拍摄日期；value = 该日期各类地物面积累计
        Map<String, Map<String, Double>> byDate = new TreeMap<>();
        for (Extraction e : all) {
            if (classType != null && !classType.isBlank()
                    && !classType.equalsIgnoreCase(e.getClassType())) {
                continue;
            }
            String date = e.getAcquisitionDate() != null
                    ? e.getAcquisitionDate().toString()
                    : (e.getYear() != null ? e.getYear() + "-01-01" : "未知日期");
            byDate.computeIfAbsent(date, k -> new LinkedHashMap<>())
                    .merge(e.getClassType(), nz(e.getExtractAreaHa()), Double::sum);
        }

        List<Map<String, Object>> out = new ArrayList<>();
        double prevTotal = 0;
        boolean first = true;
        for (Map.Entry<String, Map<String, Double>> en : byDate.entrySet()) {
            double total = 0;
            for (double v : en.getValue().values()) {
                total += v;
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("date", en.getKey());
            row.put("totalAreaHa", round2(total));
            row.put("changeHa", first ? 0.0 : round2(total - prevTotal));
            row.put("byClass", en.getValue());
            out.add(row);
            prevTotal = total;
            first = false;
        }
        return ApiResponse.ok(out);
    }

    /**
     * 采坑扩张趋势预测：对真实序列做线性外推。
     *
     * 红线：趋势外推非实测。响应带 method/disclaimer/uncertainty，
     * 前端与报告必须原样展示，不能包装成「预测准确值」。
     * 期数不足 2 期时返回空数组 + insufficient 标记，**不编数**。
     */
    @GetMapping("/pit-forecast")
    public ApiResponse<Map<String, Object>> pitForecast(@RequestParam(required = false) Long projectId,
                                                        Authentication auth) {
        List<Extraction> all = extractionService.list(projectId, auth.getName(),
                guard.roleCodesOf(auth).contains("ADMIN"));
        List<Extraction> pits = all.stream()
                .filter(e -> "PIT".equalsIgnoreCase(e.getClassType()))
                .sorted(java.util.Comparator.comparing(
                        (Extraction x) -> x.getAcquisitionDate() == null
                                ? "" : x.getAcquisitionDate().toString()))
                .toList();

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("method", "线性外推（末两期变化速率）");
        resp.put("disclaimer", "趋势外推，非实测结果；实际扩张速率受采矿计划、地形与政策等因素影响");

        if (pits.size() < 2) {
            resp.put("forecast", new ArrayList<>());
            resp.put("insufficient", true);
            resp.put("historyPeriods", pits.size());
            resp.put("message", "采坑类真实提取记录不足 2 期，无法做趋势外推");
            return ApiResponse.ok(resp);
        }

        Extraction last = pits.get(pits.size() - 1);
        Extraction prev = pits.get(pits.size() - 2);
        double lastArea = nz(last.getExtractAreaHa());
        double prevArea = nz(prev.getExtractAreaHa());
        double days = daysBetween(prev, last);
        double stepPerDay = (lastArea - prevArea) / days;

        // 不确定性带宽：历史各期变动量的标准差，随外推步长放大
        double[] deltas = new double[pits.size() - 1];
        for (int i = 1; i < pits.size(); i++) {
            deltas[i - 1] = nz(pits.get(i).getExtractAreaHa()) - nz(pits.get(i - 1).getExtractAreaHa());
        }
        double mean = 0;
        for (double d : deltas) {
            mean += d;
        }
        mean /= deltas.length;
        double var = 0;
        for (double d : deltas) {
            var += (d - mean) * (d - mean);
        }
        double sd = deltas.length > 1 ? Math.sqrt(var / (deltas.length - 1)) : Math.abs(mean);

        List<Map<String, Object>> forecast = new ArrayList<>();
        java.time.LocalDate baseDate = last.getAcquisitionDate();
        if (baseDate != null) {
            for (int i = 1; i <= 3; i++) {
                java.time.LocalDate d = baseDate.plusDays(Math.round(days * i));
                double mid = lastArea + stepPerDay * days * i;
                double band = sd * i * 1.5;      // 带宽随外推步长放大
                Map<String, Object> f = new LinkedHashMap<>();
                f.put("date", d.toString());
                f.put("areaHa", round2(Math.max(mid, 0)));
                f.put("lowerHa", round2(Math.max(mid - band, 0)));
                f.put("upperHa", round2(mid + band));
                f.put("uncertaintyHa", round2(band));
                forecast.add(f);
            }
        }

        resp.put("forecast", forecast);
        resp.put("insufficient", false);
        resp.put("historyPeriods", pits.size());
        resp.put("lastDate", baseDate == null ? null : baseDate.toString());
        resp.put("lastAreaHa", round2(lastArea));
        return ApiResponse.ok(resp);
    }

    /** 变化概览（给大屏/报告用）：各类地物面积、记录数 */
    @GetMapping("/change-summary")
    public ApiResponse<Map<String, Object>> changeSummary(@RequestParam(required = false) Long projectId,
                                                          Authentication auth) {
        List<Extraction> all = extractionService.list(projectId, auth.getName(),
                guard.roleCodesOf(auth).contains("ADMIN"));

        Map<String, double[]> byClass = new LinkedHashMap<>();   // [sumArea, count]
        for (Extraction e : all) {
            double[] agg = byClass.computeIfAbsent(e.getClassType(), k -> new double[2]);
            agg[0] += nz(e.getExtractAreaHa());
            agg[1] += 1;
        }

        List<Map<String, Object>> classes = new ArrayList<>();
        for (Map.Entry<String, double[]> en : byClass.entrySet()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("classType", en.getKey());
            m.put("totalAreaHa", round2(en.getValue()[0]));
            m.put("recordCount", (int) en.getValue()[1]);
            classes.add(m);
        }
        classes.sort((a, b) -> Double.compare((Double) b.get("totalAreaHa"),
                (Double) a.get("totalAreaHa")));

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("totalRecords", all.size());
        out.put("classes", classes);
        out.put("note", "面积来自真实解译结果累计；同一 AOI 的多期结果可用 /api/timeseries 做时序对比");
        return ApiResponse.ok(out);
    }

    private static double daysBetween(Extraction a, Extraction b) {
        if (a.getAcquisitionDate() == null || b.getAcquisitionDate() == null) {
            return 365;   // 缺日期时按年度步长近似
        }
        return Math.max(1, java.time.temporal.ChronoUnit.DAYS.between(
                a.getAcquisitionDate(), b.getAcquisitionDate()));
    }

    private static double nz(Double d) {
        return d == null ? 0.0 : d;
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}